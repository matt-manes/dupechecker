# Changelog

## v0.2.1 (2023-06-01)

#### Fixes

* fix issues during file deletion

## v0.2.0 (2023-05-31)

#### New Features

* add cli option for excluding files
* cli can accept a list of paths to compare files from

## v0.1.0 (2023-05-30)

#### Performance improvements

* enhance readability of delete_wizard()
#### Docs

* correct a few typos in pyproject.toml


