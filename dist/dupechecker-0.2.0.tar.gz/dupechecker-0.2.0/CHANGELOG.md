# Changelog

## v0.1.0 (2023-05-30)

#### Performance improvements

* enhance readability of delete_wizard()
#### Docs

* correct a few typos in pyproject.toml


